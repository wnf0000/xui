﻿using Microsoft.EntityFrameworkCore;

namespace Db
{
    public class SqliteDbContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#if DEBUG
                optionsBuilder.UseSqlite("Data Source=c:\\db\\Application.db");
#else 
optionsBuilder.UseSqlite("Data Source=db\\Application.db");
#endif
            }
        }
        public virtual DbSet<AppSetting> AppSettings { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<AppSetting>(entity =>
            {
                entity.Property(e => e.Id).HasColumnType("GUID");
                entity.Property(e => e.Key).HasColumnType("VARCHAR");
                entity.Property(e => e.Value).HasColumnType("VARCHAR");
            });
        }
    }
}