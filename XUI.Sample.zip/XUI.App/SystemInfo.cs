﻿using System.Management;
using System.Runtime.InteropServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;

namespace XUI.App
{
    public static class SystemInfo
    {
        static public List<object> GetProcessorInfo()
        {

            ManagementObjectSearcher sql = new ManagementObjectSearcher("SELECT * FROM Win32_Processor");
            List<object> processors = new List<object>();
            foreach (ManagementObject cpu in sql.Get())

            {
                dynamic processor = new System.Dynamic.ExpandoObject();

                //Processor processor = new Processor();
                //var props = processor.GetType().GetProperties();
                foreach (PropertyData prop in cpu.Properties)
                {
                    ((IDictionary<string, object>)processor).Add(prop.Name, prop.Value);
                    //var ps = cpu.Properties;
                    //prop.SetValue(processor, ((PropertyData)cpu.Properties[prop.Name]).Value);
                }


                processors.Add(processor);
            }
            return processors;

        }
        //static SystemInfo()
        //{
        //    cpuformanceCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
        //}
        //static PerformanceCounter cpuformanceCounter= new PerformanceCounter("Processor", "% Processor Time", "_Total");
        public static int GetProcessorLoadPercentage(string CpuId)
        {
            //cpuformanceCounter = cpuformanceCounter ?? new PerformanceCounter("Processor", "% Processor Time", "_Total");
            //var v = cpuformanceCounter.NextValue();
            //return (int)v;


            ManagementObjectSearcher sql = new ManagementObjectSearcher($"SELECT * FROM Win32_Processor WHERE DeviceID='{CpuId}'");
            var cpu = sql.Get().Cast<ManagementObject>().First();
            //var cpu = sql.Get().Cast<ManagementObject>().FirstOrDefault(w => w.Properties["DeviceID"].Value == CpuId);
            if (cpu != null)
            {
                //var s = cpu.Properties["LoadPercentage"].Value;
                var percentage = cpu.Properties["LoadPercentage"].Value;
                if (percentage == null) return 0;
                return (UInt16)percentage;
            }
            return 0;

        }

        public static List<object> GetDiskInfo()
        {

            ManagementObjectSearcher sql = new ManagementObjectSearcher("SELECT * FROM win32_logicaldisk");
            List<object> disks = new List<object>();
            foreach (ManagementObject mo in sql.Get())
            {
                dynamic disk = new System.Dynamic.ExpandoObject();
                foreach (PropertyData prop in mo.Properties)
                {
                    ((IDictionary<string, object>)disk).Add(prop.Name, prop.Value);

                }


                disks.Add(disk);
            }
            return disks;


        }
        public static List<dynamic> GetComputerSystemInfo()
        {

            List<dynamic> list = new List<dynamic>();
            var moc = new ManagementClass("Win32_ComputerSystem").GetInstances();

            foreach (ManagementObject mo in moc)
            {
                dynamic model = new System.Dynamic.ExpandoObject();
                foreach (var item in mo.Properties)
                {
                    ((IDictionary<string, object>)model).Add(item.Name, item.Value);

                }
                list.Add(model);
            }
            return list;


        }
        public static List<dynamic> GetOperatingSystemInfo()
        {

            List<dynamic> list = new List<dynamic>();
            var moc = new ManagementClass("Win32_OperatingSystem").GetInstances();

            foreach (ManagementObject mo in moc)
            {
                dynamic model = new System.Dynamic.ExpandoObject();
                foreach (var item in mo.Properties)
                {
                    ((IDictionary<string, object>)model).Add(item.Name, item.Value);

                }
                list.Add(model);
            }
            return list;


        }
        /// <summary>
        /// 内存信息（<see cref="https://www.cnblogs.com/zhesong/p/wmiid.html">）
        //  Attributes:1
        //  BankLabel:BANK 2
        //  Capacity:获取内存容量（单位KB）
        //  Caption:物理内存还虚拟内存
        //  ConfiguredClockSpeed:配置时钟速度
        //  ConfiguredVoltage:配置电压
        //  CreationClassName:创建类名
        //  DataWidth:获取内存带宽
        //  Description:描述
        //  DeviceLocator:获取设备定位器
        //  FormFactor:构成因素
        //  HotSwappable:是否支持热插拔
        //  InstallDate:安装日期
        //  InterleaveDataDepth:数据交错深度
        //  InterleavePosition:数据交错的位置
        //  Manufacturer:生产商
        //  MaxVoltage:最大电压
        //  MemoryType:内存类型
        //  MinVoltage:最小电压
        //  Model:型号
        //  Name:名字
        //  OtherIdentifyingInfo:其他识别信息
        //  PartNumber:零件编号
        //  PositionInRow:行位置
        //  PoweredOn:是否接通电源
        //  Removable:是否可拆卸
        //  Replaceable:是否可更换
        //  SerialNumber:编号
        //  SKU:SKU号
        //  SMBIOSMemoryType:SMBIOS内存类型
        //  Speed:速率
        //  Status:状态
        //  Tag:唯一标识符的物理存储器
        //  TotalWidth:总宽
        //  TypeDetail:类型详细信息
        //  Version:版本信息
        //  AvailableBytes:可利用内存大小（B）
        //  AvailableKBytes:可利用内存大小（KB）
        //  AvailableMBytes:可利用内存大小（MB）
        //  CacheBytes:125460480
        //  CacheBytesPeak:392294400
        //  CacheFaultsPersec:70774721
        //  Caption:
        //  CommitLimit:31939616768
        //  CommittedBytes:20280020992
        //  DemandZeroFaultsPersec:759274721
        //  Description:
        //  FreeAndZeroPageListBytes:2097152
        //  FreeSystemPageTableEntries:12528527
        //  Frequency_Object:0
        //  Frequency_PerfTime:10000000
        //  Frequency_Sys100NS:10000000
        //  LongTermAverageStandbyCacheLifetimes:14400
        //  ModifiedPageListBytes:41500672
        //  Name:
        //  PageFaultsPersec:1560432075
        //  PageReadsPersec:19173703
        //  PagesInputPersec:98834167
        //  PagesOutputPersec:25921396
        //  PagesPersec:124755563
        //  PageWritesPersec:103362
        //  PercentCommittedBytesInUse:2727084283
        //  PercentCommittedBytesInUse_Base:4294967295
        //  PoolNonpagedAllocs:0
        //  PoolNonpagedBytes:798519296
        //  PoolPagedAllocs:0
        //  PoolPagedBytes:709898240
        //  PoolPagedResidentBytes:496873472
        //  StandbyCacheCoreBytes:247545856
        //  StandbyCacheNormalPriorityBytes:847036416
        //  StandbyCacheReserveBytes:0
        //  SystemCacheResidentBytes:125460480
        //  SystemCodeResidentBytes:0
        //  SystemCodeTotalBytes:0
        //  SystemDriverResidentBytes:17592179236864
        //  SystemDriverTotalBytes:16953344
        //  Timestamp_Object:0
        //  Timestamp_PerfTime:5838028983825
        //  Timestamp_Sys100NS:132532052633540000
        //  TransitionFaultsPersec:792343233
        //  TransitionPagesRePurposedPersec:78554340
        //  WriteCopiesPersec:17253788
        /// </summary>
        /// <returns></returns>
        public static dynamic GetRAMInfo()
        {



            var model2 = new System.Dynamic.ExpandoObject();
            var searcher = new ManagementObjectSearcher()
            {
                Query = new SelectQuery("Win32_PerfRawData_PerfOS_Memory"),
            }.Get().GetEnumerator();

            while (searcher.MoveNext())
            {
                ManagementBaseObject baseObj = searcher.Current;
                foreach (var item in baseObj.Properties)
                {
                    model2.TryAdd(item.Name, item.Value);
                    //((IDictionary<string, object>)model2).Add(item.Name, item.Value);
                }
            }
            //return new List<dynamic> { model1, model2 };


            ManagementObjectSearcher sql = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMemory");
            List<object> disks = new List<object>();
            foreach (ManagementObject mo in sql.Get())
            {
                dynamic disk = new System.Dynamic.ExpandoObject();
                foreach (PropertyData prop in mo.Properties)
                {
                    ((IDictionary<string, object>)disk).Add(prop.Name, prop.Value);

                }


                disks.Add(disk);
            }
            //dynamic dy =new System.Dynamic.ExpandoObject();
            //dy.TryAdd("OSMemory", model2);
            //dy.TryAdd("PhysicalMemory", disks);
            //return dy;
            return new { OSMemory = model2, PhysicalMemory = disks };

            //MemoryStatusExE lpBuffer =new MemoryStatusExE();
            //GlobalMemoryStatusEx(ref lpBuffer);

        }

        public class Processor
        {
            public uint AddressWidth { set; get; }
            public uint Architecture { set; get; }
            public uint Availability { set; get; }
            public string Caption { set; get; }
            public uint CpuStatus { set; get; }
            public string CreationClassName { set; get; }
            public uint CurrentClockSpeed { set; get; }
            public double CurrentVoltage { set; get; }
            public uint DataWidth { set; get; }
            public string Description { set; get; }
            public string DeviceID { set; get; }
            public uint ExtClock { set; get; }
            public uint Family { set; get; }
            public uint L2CacheSize { set; get; }
            public uint L3CacheSize { set; get; }
            public uint L3CacheSpeed { set; get; }
            public uint Level { set; get; }
            public double LoadPercentage { set; get; }
            public string Manufacturer { set; get; }
            public uint MaxClockSpeed { set; get; }
            public string Name { set; get; }
            public uint NumberOfCores { set; get; }
            public uint NumberOfLogicalProcessors { set; get; }
            public bool PowerManagementSupported { set; get; }
            public string ProcessorId { set; get; }
            public uint ProcessorType { set; get; }
            public uint Revision { set; get; }
            public string Role { set; get; }
            public string SocketDesignation { set; get; }
            public string Status { set; get; }
            public uint StatusInfo { set; get; }
            public string SystemCreationClassName { set; get; }
            public string SystemName { set; get; }
            public uint UpgradeMethod { set; get; }
            public string Version { set; get; }
        };

        [DllImport("Kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)] 
        internal static extern Boolean GlobalMemoryStatusEx(ref MemoryStatusExE lpBuffer);
        //public static partial class Native
        //{
        //    ///// <summary>/// 检索有关系统当前使用物理和虚拟内存的信息
        //    ///// 
        //    ///// </summary>
        //    ///// <param name="lpBuffer"></param>
        //    ///// <returns></returns>
        //    //[LibraryImport("Kernel32.dll", SetLastError = true)]
        //    //[return: MarshalAs(UnmanagedType.Bool)]
        //    //internal static partial Boolean GlobalMemoryStatusEx(ref MemoryStatusExE lpBuffer);

        //    public class Program
        //    { static void Main { var result = GetValue; Console.WriteLine($"当前实际可用内存量：{result.ullAvailPhys / 1000 / 1000}MB");Console.ReadKey;}/// <exception cref="Win32Exception"></exception>public static MemoryStatusExE GetValue{var memoryStatusEx = new MemoryStatusExE;// 重新初始化结构的大小memoryStatusEx.Refresh;// 刷新值if (!Native.GlobalMemoryStatusEx(ref memoryStatusEx)) throw new Win32Exception("无法获得内存信息");return memoryStatusEx;}}
        //}
    }
    public struct MemoryStatusExE
    {/// <summary>
     /// 结构的大小，以字节为单位，必须在调用 GlobalMemoryStatusEx 之前设置此成员，可以用 Init 方法提前处理
     /// </summary>
     /// <remarks>应当使用本对象提供的 Init ，而不是使用构造函数！</remarks>
        internal UInt32 dwLength;
        /// <summary>
        /// 一个介于 0 和 100 之间的数字，用于指定正在使用的物理内存的大致百分比（0 表示没有内存使用，100 表示内存已满）。
        /// </summary>
        internal UInt32 dwMemoryLoad;
        /// <summary>
        /// 实际物理内存量，以字节为单位
        /// </summary>
        internal UInt64 ullTotalPhys;
        /// <summary>
        /// 当前可用的物理内存量，以字节为单位。这是可以立即重用而无需先将其内容写入磁盘的物理内存量。它是备用列表、空闲列表和零列表的大小之和
        /// </summary>
        internal UInt64 ullAvailPhys;
        /// <summary>
        /// 系统或当前进程的当前已提交内存限制，以字节为单位，以较小者为准。要获得系统范围的承诺内存限制，请调用GetPerformanceInfo
        /// </summary>
        internal UInt64 ullTotalPageFile;
        /// <summary>
        /// 当前进程可以提交的最大内存量，以字节为单位。该值等于或小于系统范围的可用提交值。要计算整个系统的可承诺值，调用GetPerformanceInfo核减价值CommitTotal从价值CommitLimit
        /// </summary>
        internal UInt64 ullAvailPageFile;
        /// <summary>
        /// 调用进程的虚拟地址空间的用户模式部分的大小，以字节为单位。该值取决于进程类型、处理器类型和操作系统的配置。例如，对于 x86 处理器上的大多数 32 位进程，此值约为 2 GB，对于在启用4 GB 调整的系统上运行的具有大地址感知能力的 32 位进程约为 3 GB 。
        /// </summary>
        internal UInt64 ullTotalVirtual;
        /// <summary>
        /// 当前在调用进程的虚拟地址空间的用户模式部分中未保留和未提交的内存量，以字节为单位
        /// </summary>
        internal UInt64 ullAvailVirtual;
        /// <summary>
        /// 预订的。该值始终为 0
        /// </summary>
        internal UInt64 ullAvailExtendedVirtual;
        internal void Refresh()
        {
            dwLength = checked((UInt32)Marshal.SizeOf(typeof(MemoryStatusExE)));
        }
    }
    public struct MEMORYSTATUS
    {
        internal UInt32 dwLength;
        internal UInt32 dwMemoryLoad;
        internal UInt32 dwTotalPhys; 
        internal UInt32 dwAvailPhys;
        internal UInt32 dwTotalPageFile;
        internal UInt32 dwAvailPageFile; 
        internal UInt32 dwTotalVirtual; 
        internal UInt32 dwAvailVirtual;
    }
}
