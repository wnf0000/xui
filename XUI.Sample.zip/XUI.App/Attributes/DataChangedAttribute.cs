﻿using System;
using System.Collections.Generic;
using System.Text;

namespace XUI.Core.Attributes
{
    [AttributeUsage(AttributeTargets.Method)]
    public class DataChangedAttribute : AfterInvokeAttribute
    {
        public override Task Excute()
        {
            return Task.Run(() => Controller.Context.MainForm.RaiseGlobalEvent(this.Controller.ListChangedEventType));
        }
    }
}
