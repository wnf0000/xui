﻿using Microsoft.Web.WebView2.Core;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace XUI.App
{
    public static class ComponentRequired
    {

        public static bool IsWebView2Installed()
        {
            //return false;
            string? res = "";
            try
            {
                res = CoreWebView2Environment.GetAvailableBrowserVersionString();
            }
            catch (System.Exception)
            {
            }
            if (res == "" || res == null)
            {
                return false;
            }
            return true;
        }

        public static async Task InstallWebview2Async()
        {
            if (!IsWebView2Installed())
            {
                
                XUI.Core.AppContext.Instance.MainForm.Text = "正在下载安装WebView2组件";
                XUI.Core.AppContext.Instance.MainForm.Controls.Clear();
                
                var label = new Label();
                label.Font = new Font(FontFamily.GenericSansSerif, 14);
                label.Visible = true;
                label.Dock = DockStyle.Fill;
                label.AutoSize = false;
                label.TextAlign = ContentAlignment.MiddleCenter;
                label.Text = "正在下载安装WebView2组件";
                XUI.Core.AppContext.Instance.MainForm.Controls.Add(label);
                
                using var webClient = new WebClient();
                bool isDownload = false;
                string MicrosoftEdgeWebview2Setup = System.IO.Path.Combine(Application.StartupPath, "MicrosoftEdgeWebview2Setup.exe");
                webClient.DownloadFileCompleted += (s, e) => { isDownload = true; };
                webClient.DownloadProgressChanged += (s, e) =>
                {
                    label.Invoke(() =>
                    {
                        label.Text = $"正在下载安装WebView2组件({e.ProgressPercentage}%)";
                    });
                };
                await webClient.DownloadFileTaskAsync("https://go.microsoft.com/fwlink/p/?LinkId=2124703", "MicrosoftEdgeWebview2Setup.exe");

                if (isDownload)
                {
                    System.Timers.Timer timer = new System.Timers.Timer();
                    timer.Interval = 1000;
                    int ticks = 0;
                    timer.Elapsed += (s, e) =>
                    {

                        label.Invoke(() =>
                        {
                            label.Text = $"安装完成后将自动重启本APP，届时请点击“是”！组件安装中({++ticks})...";
                        });
                    };
                    timer.Start();

                    _ = Process.Start(MicrosoftEdgeWebview2Setup, " /silent /install").WaitForExitAsync().ContinueWith((r) =>
                    {
                        if (IsWebView2Installed())
                        {
                            //重启
                            Application.Restart();
                            Process.GetCurrentProcess()?.Kill();
                            if (System.IO.File.Exists("MicrosoftEdgeWebview2Setup.exe"))
                            {
                                System.IO.File.Delete("MicrosoftEdgeWebview2Setup.exe");
                            }
                        }
                    }); //.WaitForExit();


                }
                
            }
        }

        //public static void DeleteWebView2Folder()
        //{
        //    string webview2Dir = $"{System.Environment.GetCommandLineArgs()[0]}.WebView2";
        //    if (Directory.Exists(webview2Dir))
        //    {
        //        Directory.Delete(webview2Dir, true);
        //    }
        //}


    }
}
