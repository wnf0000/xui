﻿using Db;
using XUI.Core;
using AppContext = XUI.Core.AppContext;

namespace XUI.App
{
    internal class MainAppForm : AppForm
    {
        SqliteDbContext db;
        public MainAppForm()
        {
            db = new SqliteDbContext();
            #region 初始化主窗口界面元素
            Width = Screen.PrimaryScreen.WorkingArea.Width * 2 / 3;
            Height = Screen.PrimaryScreen.WorkingArea.Height * 2 / 3;
            AppContext.Instance.MainForm = this;

            UseNavBar("nav.html", dockStyle: DockStyle.Left);

            //TitleBarHidden = true;//隐藏标题栏
            //CustomDragableArea = new Rectangle(0, 0, 10000, 64);//自定义拖拽区域

            Load += (s, e) =>
            {
               _= ComponentRequired.InstallWebview2Async();
            };

            #endregion


            #region 初始化主导航及主体内容元素

            DefaultWebView2.SetGuid(Guid.Parse("{C658E722-B815-404F-BB5B-A58FF5C4A81D}"));
            CustomWebView2 moudle2 = new CustomWebView2(this, Guid.Parse("{0895059A-4C18-411A-95B7-F1B6F20A601E}")) { Dock = DockStyle.Fill, Visible = false };
            CustomWebView2 moudle3 = new CustomWebView2(this, Guid.Parse("{14CBB68C-6858-453F-A3C0-E6485C38DFAB}")) { Dock = DockStyle.Fill, Visible = false };
            CustomWebView2 moudle4 = new CustomWebView2(this, Guid.Parse("{7C32BBF7-A158-44C5-B19E-37FABC632125}")) { Dock = DockStyle.Fill, Visible = false };
            CustomWebView2 moudle5 = new CustomWebView2(this, Guid.Parse("{5AAACD9D-6DF3-497E-9F05-FC527D6C5F4F}")) { Dock = DockStyle.Fill, Visible = false };
            CustomWebView2 moudle6 = new CustomWebView2(this, Guid.Parse("{1DDDB08F-82CF-4328-AF16-52CA09EB9372}")) { Dock = DockStyle.Fill, Visible = false };
            CustomWebView2 moudle7 = new CustomWebView2(this, Guid.Parse("{A1A91E15-9545-4301-B242-8C72EFE3ED19}")) { Dock = DockStyle.Fill, Visible = false };
            CustomWebView2 moudle8 = new CustomWebView2(this, Guid.Parse("{3C32B183-9CFB-4BC9-9979-A7FBDEB73AA8}")) { Dock = DockStyle.Fill, Visible = false };

            MainContainer.Controls.AddRange(new System.Windows.Forms.Control[] {
                moudle2,
                moudle3,
                moudle4,
                moudle5,
                moudle6,
                moudle7,
                moudle8
            });



            DefaultWebView2.Init().ContinueWith(r =>
            {
                this.Invoke(() =>
                {
                    DefaultWebView2.CoreWebView2.Navigate($"{AppContext.Web_Host}/main.html");
                    DefaultWebView2.BringToFront();

                });
            });

            moudle2.Init().ContinueWith(r =>
            {
                this.Invoke(() =>
                {
                    moudle2.CoreWebView2.Navigate($"{AppContext.Web_Host}/moudle2.html");
                });
            });
            moudle3.Init().ContinueWith(r =>
            {
                this.Invoke(() =>
                {
                    moudle3.CoreWebView2.Navigate($"{AppContext.Web_Host}/moudle3.html");
                });
            });
            moudle4.Init().ContinueWith(r =>
            {
                this.Invoke(() =>
                {
                    moudle4.CoreWebView2.Navigate($"{AppContext.Web_Host}/moudle4.html");
                });
            });
            moudle5.Init().ContinueWith(r =>
            {
                this.Invoke(() =>
                {
                    moudle5.CoreWebView2.Navigate($"{AppContext.Web_Host}/moudle5.html");
                });
            });
            moudle6.Init().ContinueWith(r =>
            {
                this.Invoke(() =>
                {
                    moudle6.CoreWebView2.Navigate($"{AppContext.Web_Host}/moudle6.html");
                });
            });
            moudle7.Init().ContinueWith(r =>
            {
                this.Invoke(() =>
                {
                    moudle7.CoreWebView2.Navigate(Path.GetFullPath("views/moudle7.html"));
                });
            });
            moudle8.Init().ContinueWith(r =>
            {
                this.Invoke(() =>
                {
                    moudle8.CoreWebView2.Navigate($"{AppContext.Web_Host}/moudle8.html");
                });
            });
            FormCloseDelegate.Closing += (s, e) =>
            {

                var dialog = CustomForm.ShowConfirm("确定关闭程序吗？", "提示");
                dialog.OnResult += (s, r) =>
                {
                    if (r != Dialog.DialogResult.Cancel)
                    {
                        FormCloseDelegate.RealClose();
                    }

                };
                //CustomForm.ShowConfirm1("aaaa", "提示");
            };
            

            //            IconClick += (s, e) =>
            //             {
            //                 AppForm aboutForm = new AppForm()
            //                 {
            //                     Text = "关于电脑医生",
            //                     Width = 660,
            //                     Height = 600,
            //                     MinimizeBox = false,
            //                     MaximizeBox = false,
            //                     StartPosition = FormStartPosition.CenterParent
            //                 };
            //                 aboutForm.DefaultWebView2.Init().ContinueWith(r =>
            //                 {
            //                     var html = @"
            //<style>
            //body{
            //--top-height:0px;
            //margin:auto;
            //user-select:none;
            //}
            //.top{
            //height:var(--top-height);
            //}
            //.main{
            //text-align:center;
            //background-color:#fff;
            //height:calc(100% - var(--top-height));

            //}
            //.logo{
            //margin:35px;
            //height:64px;
            //}
            //.row{
            //margin-top:15px;
            //color:#555;
            //font-size:14px;
            //}
            //.row.firstrow{
            //margin-top:auto;
            //}
            //.checkupdate{
            //margin-left: 10px;
            //    background-color: var(--skin-primary-color);
            //    color: #fff;
            //    padding: 2px 6px;
            //    cursor: pointer;
            //}
            //</style>
            //<div class='top'></div>
            //<div class='main'>
            //<img class='logo' src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJEAAACACAYAAAALUosdAAAORklEQVR4Xu2dabAcVRWAv9NJsQRI2DdBAgRFQRCQnbCEJD1hEWUpqAJLgcibISUkUIUsoiIQUChkSd6CBEplKakASYjwQgKpQATDvoggEsEEZIugESKYpI/VnXmP9+bNpPee7p7un++dc+65535z7u3bdxFS+GgX+2OxP8JIYHtgI5SNEIYCw6ouL0NZjrAcZRnCK8CrGLzMKl6Us/kobVXTh/gGFnuBsQfo7gibo2yMsAnIBv391aUoixH5G1ivA28wiMWsYrGU+DBNdZNmO6NdDMNidBWY/YADI/LpJWA2cL+UeSIim4HMaDcjQB5DZOtABmqVVP8CMhO1Zsi45tbNdq1pEGk7ozE4A/g2sF4kwW1kRPkHwiyUGVJhTqxl1RiPHKABzut7ILNQa6aU+H2SdespK1GI9BZ2YJUDzveALzajwijvI1yD0C5trIjTB32IXbBkASLbxFnO57b1vyB3YViXyRiWJFNmQplIu9gVi+sQxiVVMddylA+AazGYEgdM8Wcg1xq2o9YVUuIdV8mQArFmIp3GRqzkcuDckH7Gpx4DTCkAqBov/RSVqWBNjnMwHhtE2smZKJMRtoyPgEgt3yxl2sJaTA9AfWqi+hGiZ4jJjLD1q6cfOUTayZ4o0xD2icPhWGwqs6TCcWFtpxKg/pWaxv+sc+TYaMeCkUKkHZyPcG3YxkhUv3UAWhNW1cWIniwmz0QV58gg0g5uRzg1KscSstMt5fCD/QxkoDrhtC4Sk6ujiHNoiLSdTRBmIxwUhUMJ2ogGoAcZjsgTkU0kJhgA0Oli6klhiwwFkU5lBIOYCwwP60jC+lECZM9Eb5ew/1EWd4eY1mlhDAaGSKfyFQY5U+4937LC+JGk7gNS5uiwBeqaDJR1gHrCEAqkQBA5XZjhDMx2DNsYCesXGahxwAODFAyiDhYiHJwwAOGKUx6RCkeGMwI5y0C14QgEkm+ItJMpwISwjZGovvII63G0nM6nYcrNOUBrQiPW+TKW6/zEyRdE2s54DH7lp4CmyxYA+W8CtXaREvYaJk+PZ4i0g4MRFnqymhahAqBgLaH6pJR0f6/KniDSqWyPwQtrVuBl5lnIuowpurCg7WVdICbXeNH2BlEnDwIlLwZTImMP/M2wSzxaYgy0tgbz2K25QqQd7IewKCVweHEjGoDmsROr5VGQL3gpNJ8y+rSYuq9b3bxANBdhtJuhlPw/GoDyNZEYrmnUOlFK3LM2I2uFSDs5FFgQzovEtBchjCq6sIjjrfpnKeluwSHqwG4YewdG2p9FrGa0TODjMI62/BioYfCs08Tkjkb/bpiJtINRCA+HaZSEdAuA4g606utS0l2CQJSFLFQAFDdAvfat8WIyrV5xdTORdmDvzrQ3/6X5KQBKsnVUX5SS7ukdoi4uRrkySR99lvUsqzmsGAP5jFpY8QbzRo0yUZq7Mnvm/DBp499hYlIMogNET7lcStaPazUHQKRT2IzBLAtQRPwq9h4xi31kAkvDFFYAFDR6ulRMHbBzeSBEaf5Sb7CfnMVTQUNg6xUAhYmes1RkXxnL032tDISok1nAsSGLikP9O1Lm9jCGC4DCRK+qq9YlUmJyQ4j0OtZnSLQb2yJw2zZxr5Q5IYytAqAw0eurqzPEVPskl96nXybSdr6JwcyoiovMzmCGy3j+HtReAVDQyNXRU31LSmofPNYAok4uAwaMviN0IYip66TM+UEUnTHQA2yH4ewLy/K2nqDVj0nP2kpM3u8x3j8TddIFnBVTyf7NKh+xkuFyDsv9K/cCZG/rydq+uCDVTVDHOlZM5xQ656mFKF2DamGStHF9kOhUM1ABUJDguemoNUlKn7dLf4g6eBLBdRGSWxmR/X8wm8l4/4dc6ny25jOnCysyUGSN0ceQMllK1iX1M1EHSxDntNY0PPOlzCi/jujjrM9y+SMie/jVLeQ9R6BLTKvcqDtTz2biFlTOlQo3+i1G58h0kFDTAX7LbD15vUdMPXEARHoLm7KKf6YmIKvZRibwrh9/tJvjECOW08D8+JF/WV0gph4+EKKb2Q2LP6UkAM9K2f9Ja9rtHLBwSErqkF83VF+Wku4+EKIu9kajOz0rZAR9n5/ovI0NMkJ9mA3pc+uoqy6Wko4YCNE0tmUlb6ciEsqVUuFHfnzROfb8lmHPcxVP3BGoWbxfO0+UloH1RClzg59YaLcxBcnYQRN+Kpgm2Zpt1rXzRO+l4shg4VRp404/cSveyvxEK6yszhVTxw7ozuw/aCfPA3XX0YYt1qf+OCnT7UenGFT7iVZo2ZvFtHrP/K7tztKx5145WSrc7aeqOkceAEnPtQ9+nM+a7Fo/e3RyK3B6Cup0jpS5yY8f2m3chjgXzxRP3BFQa5yUPu8pajORvWLtorh9cLUf7O1sEhi+Tvhy9cNNQPUdxF4qKq86l+Bhz21JVq6hcKtd4/9b1o4yjjfrj4k6OAFhenDrkWlOkzLj/VjTbnZDjGQmS1WXo3q6jOPeWh+12/ZbbkBkiB//syQrptUv+fTPRL9hA1aE288eSTCU2VLxv85bu+Wd+A8l1xcYrEfLkY3n1PRhdmalPIDIlyKJR5qMqD4nJd27r0v1FurPg/CnrIas9zIps4VfG9rNxYgR46ZLfZ4hOkpGut8vq/PYitXyOMhOfuuRcvkbxbT6XT02EKIuJqL8MgUV2VfK/bemePFJu+VNRHbwIutLRvUpLB0tR3lfZZlLkMQ6XMb2P26oXiayT394zVeA4xC2d1tW/K/31rkcgGVEe3GwDdC6OkqO8N/V5wok1Q+lpJvVNnf9bdSdzvGzO8fBhg+bL0iZr/uQ7xXVh2hDjc4gugN19HHWUTMIQD22cgTSNDGtAS88jfbi2/e1ToqmEUJYMdhLznJm0X0/OocKGO2+FfsqqM5hpR4fxSVzuQBJrWPq3XjdCKK0HHA1U8p8KygI+iDHI3IbIkMD2LhJTOucAHoNVaprv+01T73LKKK0H68t/URM3bBeGY1PSuvkjVRcQSXsI208GzRAej9DWIczQX4A0vC0rzX29V8gd4N1tZhO/SN/MgzS78S0TvELkX0H1m8jj6JfgwHnjOoVo/P4Kqs5CowRqG4NrAf23BJvI9Z8GZvM8YJO17ZKFiDyZb/haJq8WIfIWP7gCyLnd9nJK8CuTXO8p2Blb6nwXNP9iNCBbI2RdLaY2vCQj7UfQdzBMQj3Rxi7oKZekjK52wKUGZAMaw8Z0/j4RS+Hoafj1DTlTqlk7qJi1x9NBkByvQPNHaJ0HYg+QcqEe213bdbkBdINkrWT20uGK0TVsZG9eT/0vamRNI/FoXI2j0ViK0VG0gmSdamYXOEWJm8QdfE1lBfdjCX0/xXAKVJOxVgNvZUt+IyJUqF3b3rQOKQLJF0kph7gpS6eIHKyUQeXIvzMi9FEZJSzpUJHImU1KETbOQDDWVO0DcosqXBcWH9SAZLqfxDdTUxvB6x6hqjardnrnk8KG6gI9UMdgBXGj7o/qihBauY8koebhfrGzhdEVZDs+ZpAH0bDNFpDXXvXrsEEaUvmTjbtYnPU2URwRF2fogJpPpvzmSxswoTkrWJaZ/ppK/8QdTmp+xknhafpUe5kMD+U7/NWHG7pjQxlXSahTAQ2XmsZUYE0hy1BFoAkM+GruhjRPcXkEz8x9A2Rk43W7Nu3p8DX81NYIrLKLxjEXUG//tf66MCzjgPOecAwH3UI9fG4pxxNKiOpvomlI+Uo/z/CQBBVu7XjYe038vkIeByi9gfU+xDukzZ/t2jrVDbEYAxCCeWkEBcoZwMk1bew9MAgANkNFxii6htbBcnE5J89LfAa6qzYtL8H/hWchfYGODdsD8NgKBYbI85tk/XHO8FQnyFl+p37HMRMbBnJBkh1ZN8tQH79CwVRxkDyG5vo5KMaI0XdtUUAUOhM1Ntvd5CVjBQdGH4tpQ2kiACKDKIiI3kkKi0gRQhQpBAVIGUEJNV3UT0wzBiotqahx0QDXomLrs2dpmZlJBsgdKSUnN08kT2RQ1RkJI9tkzRIMQEUeXfWN3xaZCR3mpICKUaAYoWoyEjuDDkScYOk+gHoQVF3YX1rF0t31i8jpWdvv8dWbYJYXCDZAIkeKiavxlmr2CFyfmwFSO5tGDVIsGkSAMXenRUZyZ2dfhJRgWR//Ve2kBIv+/QgkHgimajHsyIjeWqj6VJO1cI/V6cThajo2lzbo0cgUyAlDlEBUv5AagpEBUj5AqlpEBUg5QekpkJUnZC8EOEqzyFtTcFUj5GaDlEBkudfRWpBSgVEBUjZBik1EFVBugRx3/vtOeT5FPR920DcYUgVREVGcmlu5WMMRie1UdMrfKmDqACpQdOlFCDb21RCVIBUA1KKAUo1RNV5pJ+g/NRrWs2p3AqEUWnrwvrGOrWZqMdJ7eAqhAtzCohbtWyATL87eN2MRv3/1ENU7dpaEaRMAJT67qzvL6bFMlJmAMoURC2UkTIFUOYgagGQMgdQJiHKMUiZBCizEOUQpMwClGmIHJA6nWtG7VPMsvxkGqDMQ5QDkDIPUC4gyjBIuQAoNxBlEKTcAJQriDIEUq4Ayh1EGQApdwDlEqIUg5RLgHILUQpByi1AuYaoOiHZjlBp8iRSrgHKPUQpACn3ALUERE0EqSUAahmImgBSywDUUhAlCFJLAdRyECUAUssB1JIQxQhSSwLUshDFAFLLAtTSEFVB+jnCBaHmkZTlwFFScW6ibMknE1uG4myZkCf/L7FvaJSznMv4WvZpeYicjDSVERich/BdYIgHGuxbHK/H4NfShn2rY0s/BUR9mt+5+3Uw41Dnus3dUbZF2AxlKbAE4VGUGVLhyZampqbyBUQFDaEjUEAUOoSFgQKigoHQESggCh3CwsD/AT7QWczf6I+iAAAAAElFTkSuQmCC'/>
            //<div class='row firstrow'><span>电脑医生 v1.01b</span> <span class='checkupdate'>检查更新</span></div>
            //<div class='row'>阳光网络科技有限公司 版权所有</div>
            //<div class='row'>© CopyRight 2022 All Rights Reserved.</div>
            //</div>
            //";
            //                     this.Invoke(() => aboutForm.DefaultWebView2.NavigateToString(html));
            //                 });
            //                 aboutForm.DefaultWebView2.NavigationCompleted += (s, e) =>
            //                 {
            //                     aboutForm.ShowDialog();
            //                 };


            //             };
            #endregion

            TitleBarInited += (s, e) => {
                //添加主题中心按钮
                AddTitleBarIcon("""
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-palette" viewBox="0 0 16 16">
                      <path d="M8 5a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zm4 3a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3zM5.5 7a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0zm.5 6a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3z"/>
                      <path d="M16 8c0 3.15-1.866 2.585-3.567 2.07C11.42 9.763 10.465 9.473 10 10c-.603.683-.475 1.819-.351 2.92C9.826 14.495 9.996 16 8 16a8 8 0 1 1 8-8zm-8 7c.611 0 .654-.171.655-.176.078-.146.124-.464.07-1.119-.014-.168-.037-.37-.061-.591-.052-.464-.112-1.005-.118-1.462-.01-.707.083-1.61.704-2.314.369-.417.845-.578 1.272-.618.404-.038.812.026 1.16.104.343.077.702.186 1.025.284l.028.008c.346.105.658.199.953.266.653.148.904.083.991.024C14.717 9.38 15 9.161 15 8a7 7 0 1 0-7 7z"/>
                    </svg>
                    """, "theme-icon", 
                    $$"""
                    async function(){
                      let windowId= await xui.openUrl("{{AppContext.Web_Host}}/themecentertab.html",{text:'主题中心',width:1800,height:1150},
                        ()=>{  
                            xui.ui.TitleBar.extend("<h3 style='text-align:center'>当今世界最流行的Windows主题<sup>®</sup></h3>",180);
                            //xui.ui.setWindowFeatures({height:1300});
                        }
                      );
                      
                    }
                    """);
               //添加切换布局按钮
                AddTitleBarTwoStateIcon(true, """
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-window" viewBox="0 0 16 16">
                      <path d="M2.5 4a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1zm2-.5a.5.5 0 1 1-1 0 .5.5 0 0 1 1 0zm1 .5a.5.5 0 1 0 0-1 .5.5 0 0 0 0 1z"/>
                      <path d="M2 1a2 2 0 0 0-2 2v10a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V3a2 2 0 0 0-2-2H2zm13 2v2H1V3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1zM2 14a1 1 0 0 1-1-1V6h14v7a1 1 0 0 1-1 1H2z"/>
                    </svg>
                    """, """
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-layout-sidebar" viewBox="0 0 16 16">
                      <path d="M0 3a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2V3zm5-1v12h9a1 1 0 0 0 1-1V3a1 1 0 0 0-1-1H5zM4 2H2a1 1 0 0 0-1 1v10a1 1 0 0 0 1 1h2V2z"/>
                    </svg>
                    """, "layout-icon", "()=>xui.invokeAction(\"MainFormController\",\"ChangeLayout\",{width:400,height:150})");

                //MessageBox.Show(this.CreateGraphics().DpiX.ToString());
            };
            Update();

        }

        void AddOrUpdateLayoutSetting(string key, string value)
        {
            var entity = db.AppSettings.FirstOrDefault(w => w.Key == key);
            if (entity == null)
            {
                entity = new AppSetting()
                {
                    Key = key,
                    Value = value
                };
                db.AppSettings.Add(entity);
            }
            else
            {
                entity.Value = value;
            }
            db.SaveChanges();
        }
        string GetLayoutDirection()
        {
            var setting = db.AppSettings.FirstOrDefault(w => w.Key == SettingKeys.LayoutDirection);
            if (setting == null) return "v";
            return setting.Value;
        }
    }
}
