using Db;
using XUI.Core;
using XUI.Core.Extention;
using AppContext = XUI.Core.AppContext;
namespace XUI.App
{
    internal static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();
            var app = AppContext.Instance;
            app.UseAppName("����ҽ�� 1.0");
            var sk = XUI.Core.Tools.ThemeTool.GetDefaultTheme();
            app.GlobalSkin = sk.ToTheme();
            app.AddVirtualHost("theme.local.loc", "themes");

            //app.UseFont("font/fontawesome-webfont.ttf");
            //app.UseFont("font/iconfont.ttf");
            //app.UseFont("font/bootstrap-icons.ttf");
            app.Services.AddSingleton<SqliteDbContext>();
            app.UseController();

            app.StartHook();
            var mainForm = new MainAppForm() { Text = app.AppName };
            mainForm.Height += 160;
            Application.Run(mainForm);

            app.StopHook();
            Application.Exit();

        }
    }
}