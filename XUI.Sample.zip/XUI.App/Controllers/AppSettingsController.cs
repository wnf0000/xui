﻿using Db;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using XUI.Core;
using XUI.Core.Attributes;

namespace XUI.App.Controllers
{
    public class AppSettingsController : Controller
    {
        [Inject]
        SqliteDbContext db;
        public ActionResult SetOrUpdate(AppSettings settings)
        {
            if (settings == null) return ActionResult.StatusFalseResult("请传入正确数据!");

            if (settings.Id == Guid.Empty)
            {
                db.AppSettings.Add(settings);
                db.SaveChanges();
            }
            else
            {
                var entity = db.AppSettings.FirstOrDefault(w => w.Id == settings.Id);
                if (entity == null) return ActionResult.StatusFalseResult("设置项不存在！");
                entity.Value = settings.Value;
                db.SaveChanges();
            }
            return ActionResult.StatusTrueResult("操作成功！");
        }
        public ActionResult GetAppSetting(string key)
        {
            var entity = db.AppSettings.FirstOrDefault(w => w.Key == key);
            if (entity == null) return ActionResult.StatusFalseResult("配置项不存在！");
            return ActionResult.DataResult(entity);
        }
    }
}
