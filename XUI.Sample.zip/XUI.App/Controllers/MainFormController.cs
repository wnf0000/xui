﻿using XUI.Core;

namespace XUI.App.Controllers
{
    public class MainFormController:XUI.Core.Controller
    {
        public ActionResult ChangeLayout(int width=400,int height=64)
        {
            switch (Context.MainForm.NavWebView.Dock)
            {
                case DockStyle.Top:
                    Context.MainForm.NavBarLayout(DockStyle.Left, width, height);
                    break;
                default:
                    Context.MainForm.NavBarLayout(DockStyle.Top, width, height);
                    break;
            }
            return ActionResult.VoidResult();
        }
    }
}
