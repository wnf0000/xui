﻿using Db;
using XUI.Core;
using XUI.Core.Attributes;

namespace XUI.App.Controllers
{
    public class AppSettingController : Controller
    {
        [Inject]
        SqliteDbContext db;
        public ActionResult GetAppSettings()
        {
            return ActionResult.DataResult(db.AppSettings.ToArray());
        }
        [DataChanged]
        public ActionResult Create(AppSetting model)
        {
            if (model == null) return ActionResult.StatusFalseResult("请传入正确的参数！");
            //检查Key是否已存在
            if (db.AppSettings.FirstOrDefault(w => w.Key == model.Key) != null)
                return ActionResult.StatusFalseResult($"Key:{model.Key}已存在，请重新设置！");
            db.AppSettings.Add(model);
            db.SaveChanges();
            return ActionResult.StatusTrueResult("新增成功！");
        }
        [DataChanged]
        public ActionResult Edit(AppSetting model)
        {
            if (model == null) return ActionResult.StatusFalseResult("请传入正确的参数！");
            var entity = db.AppSettings.FirstOrDefault(w => w.Key == model.Key);
            if (entity == null) return ActionResult.StatusFalseResult("编辑的对象不存在！");
            entity.Value = model.Value;
            db.SaveChanges();
            return ActionResult.StatusTrueResult("编辑成功！");
        }
        [DataChanged]
        public ActionResult Delete(Guid id)
        {
          var entity =  db.AppSettings.FirstOrDefault(w => w.Id == id);
            if (entity == null) return ActionResult.StatusFalseResult("对象不存在！");
            db.AppSettings.Remove(entity);
            db.SaveChanges();
            return ActionResult.StatusTrueResult("删除成功！");
        }

    }
}
