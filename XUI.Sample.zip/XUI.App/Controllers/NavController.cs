﻿using XUI.Core;

namespace XUI.App.Controllers
{
    public class NavController:Controller
    {
        public ActionResult Switch(Guid moudleGuid)
        {
            var webView = Context.MainForm.CustomWebViewList.FirstOrDefault(w => w.Guid == moudleGuid);
            if (webView == null)
            {
                return ActionResult.StatusFalseResult("模块不存在！");
            }
            else
            {

                webView.BringToFront();
                webView.Visible = true;
                //foreach (Control wb in Context.MainForm.MainContainer.Controls)
                //{
                //    if (wb.Visible &&wb!=webView)
                //    {

                //        wb.Visible = false;
                //    }

                //}
                
                return ActionResult.StatusTrueResult("成功");
            }
             
        }
    }
}
