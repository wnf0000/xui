﻿using System.Timers;
using XUI.Core;
using Message = XUI.Core.Message;
using Timer = System.Timers.Timer;

namespace XUI.App.Controllers
{
    public class SystemController : Controller
    {
        static Timer timer;
        public async Task<ActionResult> GetProcessorInfo(Message message)
        {
            var infos = SystemInfo.GetProcessorInfo();
            if (timer == null)
            {
                timer = new Timer();
                timer.Interval = 1000;
                timer.Elapsed += (s, e) =>
                {
                    foreach (dynamic info in infos)
                    {
                        //this.Context.MainForm.CustomWebViewList.ForEach(webview =>
                        //{
                        this.Context.MainForm.CustomWebViewList.FirstOrDefault(w => w.Guid == message.WebViewGuid)?.RaiseUiEvent("cpu_loadPercentage", new
                        {
                            DeviceID = info.DeviceID,
                            LoadPercentage = SystemInfo.GetProcessorLoadPercentage(info.DeviceID)
                        });
                        //});
                    }
                };
                timer.Start();
            }

            return ActionResult.DataResult(infos);
        }

        public async Task<ActionResult> GetComputerInfo()
        {
            return ActionResult.DataResult(new { Os = (SystemInfo.GetOperatingSystemInfo()).First(), Computer = (SystemInfo.GetComputerSystemInfo()).First() });
        }

        public async Task<ActionResult> GetOperatingSystemInfo()
        {
            return ActionResult.DataResult(SystemInfo.GetOperatingSystemInfo());
        }
        public async Task<ActionResult> GetCpuLoadPercentage(string CpuID)
        {
            return ActionResult.DataResult(SystemInfo.GetProcessorLoadPercentage(CpuID));
        }

        public async Task<ActionResult> GetDiskInfo()
        {

            var infos = SystemInfo.GetDiskInfo();
            return ActionResult.DataResult(infos);
        }

        public async Task<ActionResult> GetRAMInfo()
        {
            return ActionResult.DataResult( SystemInfo.GetRAMInfo());
        }
        public async Task<ActionResult> GetComputerSystemInfo()
        {
            return ActionResult.DataResult(SystemInfo.GetComputerSystemInfo());
        }
    }
}
