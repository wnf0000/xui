﻿using XUI.Core;
using XUI.Core.Attributes;
using XUI.Core.Tools;
using XUI.Core.ViewModels;
using static XUI.Core.AppForm;
using AppContext = XUI.Core.AppContext;

namespace XUI.App.Controllers
{
    public class SkinCenterController : Controller
    {
        //[RequiredLogin]
        public ActionResult GetSkins()
        {
            var allThemes = ThemeTool.GetAllThemes();
            var images = allThemes.Where(w => w.Type == "image");
            var colors = allThemes.Where(w => w.Type == "color");
            return ActionResult.DataResult(new { ImageThemes = images, ColorThemes = colors });

        }
        public ActionResult ApplySkin(ThemeModel themeModel)
        {
            if (themeModel == null) return ActionResult.StatusFalseResult("主题数据不正确");

            AppContext.Instance.ApplyTheme(themeModel.ToTheme(),themeModel);
            themeModel.Default = true;
            ThemeTool.SaveAsDefault(themeModel);
            return ActionResult.StatusTrueResult("主题应用成功！");
        }
    }
}
